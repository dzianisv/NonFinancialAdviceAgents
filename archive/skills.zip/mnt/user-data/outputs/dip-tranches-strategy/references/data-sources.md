# Live Market Data Sources for Dip Detection

This reference covers how to retrieve the live price data needed to compute drawdown from 52-week high for VOO/IVV/SPLG/SPY. It is loaded only when the skill needs to discuss or implement live data retrieval.

## Decision tree: which source?

| Use case | Recommended source | Why |
|---|---|---|
| One-off check, low volume, hobby/personal | `yfinance` (Python) | Free, no API key, simplest setup |
| Daily nightly cron job (1-10 tickers, 1x/day) | `yfinance` with caching, OR `xfinance` (drop-in) | Free, sufficient for daily polls |
| Production agent with reliability needs | Alpha Vantage / Twelve Data / Finnhub free tier | Has documented SLAs, won't randomly break |
| Real-time intraday, multi-ticker monitoring | Polygon.io (paid, $29+/mo) | WebSocket streams, low latency |
| Already using a broker that has data API | Broker API (Alpaca, IBKR, Schwab) | One less dependency, free for account holders |

## Source 1: yfinance (Python) — the default starting point

The most popular Python library for retrieving Yahoo Finance data. YFinance is the go-to library for accessing Yahoo Finance data in Python, offering historical prices, dividends, splits, and basic fundamentals.

### Setup
```bash
pip install yfinance
```

### Minimal example — pull 52-week data and compute drawdown
```python
import yfinance as yf
from datetime import datetime, timedelta

def check_drawdown(ticker: str = "VOO") -> dict:
    """Return current drawdown from 52-week high."""
    end = datetime.now()
    start = end - timedelta(days=400)  # buffer beyond 365 for weekends/holidays

    t = yf.Ticker(ticker)
    hist = t.history(start=start, end=end, interval="1d")

    if hist.empty:
        raise RuntimeError(f"No data returned for {ticker}")

    # Use last 252 trading days as proxy for 52 weeks
    last_year = hist.tail(252)
    high_52w = last_year["High"].max()
    current = hist["Close"].iloc[-1]
    drawdown_pct = (current - high_52w) / high_52w * 100

    return {
        "ticker": ticker,
        "current": float(current),
        "high_52w": float(high_52w),
        "drawdown_pct": float(drawdown_pct),
        "as_of": hist.index[-1].strftime("%Y-%m-%d"),
    }

if __name__ == "__main__":
    result = check_drawdown("VOO")
    print(f"{result['ticker']} @ ${result['current']:.2f}")
    print(f"52w high: ${result['high_52w']:.2f}")
    print(f"Drawdown: {result['drawdown_pct']:.2f}%")
```

### Critical caveats with yfinance

yfinance is unofficial and scrape-based. The library relies on unofficial web scraping of Yahoo Finance rather than connecting to a supported API endpoint, carrying inherent risks of screen scraping. This scraping approach creates immense pipeline fragility and risk of stale data. Analysts frequently encounter sudden rate limits, blocked IP addresses, and completely broken requests when the underlying website structure changes.

Practical implications:

- **Rate limits are undocumented and change without notice.** Yahoo can throttle or block your IP, especially during peak market hours.
- **The library frequently has open bug reports.** As of mid-2026 there are 30+ open issues on the yfinance GitHub.
- **Cloud-hosted IPs get blocked more aggressively** than residential ones. If you run from AWS, GCP, or PythonAnywhere, expect occasional outages.
- **Never put yfinance in the hot path of real money decisions** without a backup source.

### Mitigations
- **Cache aggressively.** For a daily-cron use case, you only need to pull once per day. Save to local SQLite or a JSON file and reuse.
- **Add retry with exponential backoff.** Wrap calls in `tenacity` or similar.
- **Run during off-peak hours.** Late evening US time is typically more reliable than market hours.
- **Have a backup source configured** for production use.

## Source 2: xfinance — yfinance with failover

A newer drop-in replacement that adds multi-source failover. A Python financial data library with automatic multi-source failover. xFinance delivers yfinance's beloved simplicity with better reliability. When Yahoo Finance is rate-limited or unavailable, data transparently falls back to alternative sources (Stooq, SEC, ECB, Binance, CoinGecko). No code changes. No API keys needed.

```bash
pip install xfinance
```

API is largely yfinance-compatible. Worth trying if yfinance reliability is a concern and you don't want to manage an API key.

## Source 3: Alpha Vantage — free tier with API key

Free tier is tight but stable and has documented terms. Alpha Vantage remains the most popular free financial API. The 25 requests/day free tier is tight, but covers stocks, forex, crypto, fundamentals, and 50+ technical indicators.

Sign up at alphavantage.co to get a free API key.

### Example
```python
import requests

API_KEY = "YOUR_KEY_HERE"

def alpha_vantage_daily(ticker: str = "VOO"):
    url = "https://www.alphavantage.co/query"
    params = {
        "function": "TIME_SERIES_DAILY",
        "symbol": ticker,
        "outputsize": "full",  # full = 20+ years; compact = 100 days
        "apikey": API_KEY,
    }
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    data = r.json()
    return data["Time Series (Daily)"]
```

**Free tier limit: ~25 calls/day.** Plenty for a single-ticker daily cron, insufficient for multi-ticker monitoring. Paid tiers start around $50/month.

## Source 4: Twelve Data — most generous free tier

Twelve Data wins on global coverage with 50+ exchanges and 130+ API-calculated technical indicators. The 800 requests/day free tier is the most generous among established providers.

Free tier: 800 requests/day, 8 requests/minute. Sign up at twelvedata.com.

```python
import requests

API_KEY = "YOUR_KEY"

def twelve_data_time_series(ticker: str = "VOO"):
    url = "https://api.twelvedata.com/time_series"
    params = {
        "symbol": ticker,
        "interval": "1day",
        "outputsize": 365,
        "apikey": API_KEY,
    }
    r = requests.get(url, params=params, timeout=10)
    return r.json()
```

## Source 5: Polygon.io — production-grade

Polygon.io is the strongest choice for real-time US market data. WebSocket feeds, tick-level historical data, and unlimited API calls on paid plans make it the go-to for production trading apps.

Free tier exists but is heavily limited (1 year of history, 5 calls/minute). Paid plans start ~$29/month. Worth it if running an automated agent that you actually trust with money.

## Source 6: Broker APIs (Alpaca, IBKR)

If the user already has a brokerage account, the broker's API is often the best source for production:

- **Alpaca** — free for users; modern REST + WebSocket API; can also place trades. `pip install alpaca-py`
- **Interactive Brokers** — TWS API or IBKR Web API; requires their gateway running. More setup but institutional-grade.
- **Schwab** — has a developer API as of 2024+ after the TD Ameritrade migration. Application/approval required.

For a dip-tranche agent that places real orders, using the broker's own data feed eliminates one source of error (you're trading on the same prices you analyzed on).

## Recommended setup by user scale

### Hobbyist / learning ($0 budget)
- yfinance, run daily at 5pm ET
- Cache to local JSON file
- Email/Telegram alerts via free webhook service

### Serious DIY investor ($0-50/month)
- Primary: Twelve Data free tier (or yfinance with caching)
- Backup: Alpha Vantage free tier
- Run on a $5/month VPS or free GitHub Actions cron

### Automated trading ($50-200/month)
- Data: Polygon.io basic ($29/mo) or broker API
- Compute: AWS Lambda + EventBridge, or simple VPS
- Trading: Alpaca or IBKR API (notification-only at first!)

## Useful tickers for this skill

Common index ETFs and what they track:

| Ticker | Tracks | Issuer |
|---|---|---|
| VOO | S&P 500 | Vanguard |
| IVV | S&P 500 | iShares (BlackRock) |
| SPLG / SPYM | S&P 500 | State Street |
| SPY | S&P 500 | State Street (oldest, higher fee, tighter spreads) |
| VTI | CRSP US Total Market | Vanguard |
| ITOT | S&P Total US Market | iShares |
| ^GSPC | S&P 500 Index (not tradeable, raw index) | — |
| ^VIX | Volatility Index (for fundamental health check) | — |

For dip detection on the S&P 500, use VOO or `^GSPC` directly. The ETF will slightly lag the index due to expense ratio drag (~0.03%/year), which is negligible for drawdown calculation.
